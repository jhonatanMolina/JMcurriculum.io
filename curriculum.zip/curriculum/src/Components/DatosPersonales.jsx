import React from 'react';

function DatosPersonales() {
  return (
    <div className='row my-4'>
        <div className="col-lg-4 d-flex justify-content-center">
        <img src="foto.jpg" class="img-thumbnail" alt="foto HDV"/>
        </div>
        <div className="col-lg-8">
          <h2>Datos Personales</h2>
          <p>Jhonatan Molina Castro</p>
          <p>Correo electrónico: jmolina64@cuc.edu.co</p>
          <p>Teléfono: 322222222</p>
        </div>
    </div>
    

  );
}

export default DatosPersonales;