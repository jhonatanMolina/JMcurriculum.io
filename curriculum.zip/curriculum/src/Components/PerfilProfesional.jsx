import React from 'react';

function PerfilProfesional() {
  return (
    <div>
      <h2>Perfil Profesional</h2>
      <hr className='border-primary'/>
      <p>Estudiante de VIII semestre de Ingeniería de sistemas con conocimientos en diferentes lenguajes de programación y base de datos; responsable, con la facilidad de adaptación y capacidad de trabajar en equipo en condiciones de alta presión, con un aprendizaje continuo y habilidades sociales.</p>
    </div>
  );
}

export default PerfilProfesional;