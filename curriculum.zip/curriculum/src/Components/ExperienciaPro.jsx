import React from 'react';

function ExperienciaPro() {
  return (
    <div>
      <h2>Experiencia Profesional</h2>
      <hr className='border-primary'/>

      <ul>
        <li>
          <strong>Nombre de la empresa:</strong> Zoologico BAQ
          <br />
          <strong>Puesto:</strong> interprete
          <br />
          <strong>Fecha:</strong> 2018-2019
          <br />
          <p>Guiar a las personas y ayudarlas en su recorrido por el Zoologico.</p>
        </li>
      </ul>
    </div>
  );
}

export default ExperienciaPro;