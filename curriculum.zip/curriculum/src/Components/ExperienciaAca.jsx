import React from 'react';

function ExperienciaAca() {
  return (
    <div>
      <h2>Experiencia Académica</h2>
      <hr className='border-primary'/>

      <ul>
        <li>
          <strong>Institución:</strong> Villa estadio
          <br />
          <strong>Título:</strong> Bachiller
          <br />
          <strong>Fecha:</strong> 2019
        </li>
        <h1></h1>
        <li>
          <strong>Institución:</strong> SENA
          <br />
          <strong>Título:</strong> Tecnico en programación de software
          <br />
          <strong>Fecha:</strong> (2018-2019)
        </li>
        <h1></h1>
        <li>
          <strong>Institución:</strong> Universidad de la Costa
          <br />
          <strong>Título:</strong> Ingeniero de Sistemas
          <br />
          <strong>Fecha:</strong> (2020-presente)
        </li>
      </ul>
    </div>
  );
}

export default ExperienciaAca;