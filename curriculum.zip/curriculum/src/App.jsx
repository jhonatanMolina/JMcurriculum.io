import { useState } from 'react'
import DatosPersonales from './components/DatosPersonales';
import PerfilProfesional from './components/PerfilProfesional';
import ExperienciaPro from './components/ExperienciaPro';
import ExperienciaAca from './components/ExperienciaAca';
import "./App.css"

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="container-lg card my-5 p-4">
  
    <h1 class="display-5 text-center mt-4">Curriculum Jhonatan Molina</h1>
    <DatosPersonales />
    <PerfilProfesional />
    <ExperienciaPro />
    <ExperienciaAca />
    
    </div>

  )
}

export default App
